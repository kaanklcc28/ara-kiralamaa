﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Label1 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Label5 As System.Windows.Forms.Label
        Dim Label6 As System.Windows.Forms.Label
        Dim Label7 As System.Windows.Forms.Label
        Dim Label8 As System.Windows.Forms.Label
        Dim Label9 As System.Windows.Forms.Label
        Dim Label10 As System.Windows.Forms.Label
        Dim Label11 As System.Windows.Forms.Label
        Dim Label12 As System.Windows.Forms.Label
        Dim Label13 As System.Windows.Forms.Label
        Dim Label14 As System.Windows.Forms.Label
        Dim Surucu_AdiLabel As System.Windows.Forms.Label
        Dim Kefil_AdLabel As System.Windows.Forms.Label
        Dim Kefil_SoyadLabel As System.Windows.Forms.Label
        Dim Kefil_AdresLabel As System.Windows.Forms.Label
        Dim Kefil_TelefonLabel As System.Windows.Forms.Label
        Dim Kefil_Cep_TelefonuLabel As System.Windows.Forms.Label
        Dim Label15 As System.Windows.Forms.Label
        Dim PlakaLabel As System.Windows.Forms.Label
        Dim MarkaLabel As System.Windows.Forms.Label
        Dim TipLabel As System.Windows.Forms.Label
        Dim ModelLabel As System.Windows.Forms.Label
        Dim RenkLabel As System.Windows.Forms.Label
        Dim GünlükLabel As System.Windows.Forms.Label
        Dim HaftalıkLabel As System.Windows.Forms.Label
        Dim AylıkLabel As System.Windows.Forms.Label
        Dim Çıkış_ZamanıLabel As System.Windows.Forms.Label
        Dim Dönüş_ZamanıLabel As System.Windows.Forms.Label
        Dim Ek_TutarLabel As System.Windows.Forms.Label
        Dim ToplamLabel As System.Windows.Forms.Label
        Dim AcıklamaLabel As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker3 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker4 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button6 = New System.Windows.Forms.Button()
        Label1 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Label5 = New System.Windows.Forms.Label()
        Label6 = New System.Windows.Forms.Label()
        Label7 = New System.Windows.Forms.Label()
        Label8 = New System.Windows.Forms.Label()
        Label9 = New System.Windows.Forms.Label()
        Label10 = New System.Windows.Forms.Label()
        Label11 = New System.Windows.Forms.Label()
        Label12 = New System.Windows.Forms.Label()
        Label13 = New System.Windows.Forms.Label()
        Label14 = New System.Windows.Forms.Label()
        Surucu_AdiLabel = New System.Windows.Forms.Label()
        Kefil_AdLabel = New System.Windows.Forms.Label()
        Kefil_SoyadLabel = New System.Windows.Forms.Label()
        Kefil_AdresLabel = New System.Windows.Forms.Label()
        Kefil_TelefonLabel = New System.Windows.Forms.Label()
        Kefil_Cep_TelefonuLabel = New System.Windows.Forms.Label()
        Label15 = New System.Windows.Forms.Label()
        PlakaLabel = New System.Windows.Forms.Label()
        MarkaLabel = New System.Windows.Forms.Label()
        TipLabel = New System.Windows.Forms.Label()
        ModelLabel = New System.Windows.Forms.Label()
        RenkLabel = New System.Windows.Forms.Label()
        GünlükLabel = New System.Windows.Forms.Label()
        HaftalıkLabel = New System.Windows.Forms.Label()
        AylıkLabel = New System.Windows.Forms.Label()
        Çıkış_ZamanıLabel = New System.Windows.Forms.Label()
        Dönüş_ZamanıLabel = New System.Windows.Forms.Label()
        Ek_TutarLabel = New System.Windows.Forms.Label()
        ToplamLabel = New System.Windows.Forms.Label()
        AcıklamaLabel = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label1.Location = New System.Drawing.Point(40, 40)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(75, 17)
        Label1.TabIndex = 67
        Label1.Text = "Müşteri Ekle:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label3.Location = New System.Drawing.Point(40, 65)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(72, 17)
        Label3.TabIndex = 66
        Label3.Text = "Tc Kimlik No:"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label4.Location = New System.Drawing.Point(40, 91)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(24, 17)
        Label4.TabIndex = 68
        Label4.Text = "Ad:"
        '
        'Label5
        '
        Label5.AutoSize = True
        Label5.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label5.Location = New System.Drawing.Point(40, 117)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(41, 17)
        Label5.TabIndex = 69
        Label5.Text = "Soyad:"
        '
        'Label6
        '
        Label6.AutoSize = True
        Label6.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label6.Location = New System.Drawing.Point(40, 173)
        Label6.Name = "Label6"
        Label6.Size = New System.Drawing.Size(76, 17)
        Label6.TabIndex = 70
        Label6.Text = "Dogum Tarihi:"
        '
        'Label7
        '
        Label7.AutoSize = True
        Label7.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label7.Location = New System.Drawing.Point(40, 198)
        Label7.Name = "Label7"
        Label7.Size = New System.Drawing.Size(68, 17)
        Label7.TabIndex = 71
        Label7.Text = "Dogum Yeri:"
        '
        'Label8
        '
        Label8.AutoSize = True
        Label8.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label8.Location = New System.Drawing.Point(40, 224)
        Label8.Name = "Label8"
        Label8.Size = New System.Drawing.Size(48, 17)
        Label8.TabIndex = 72
        Label8.Text = "Telefon:"
        '
        'Label9
        '
        Label9.AutoSize = True
        Label9.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label9.Location = New System.Drawing.Point(40, 250)
        Label9.Name = "Label9"
        Label9.Size = New System.Drawing.Size(74, 17)
        Label9.TabIndex = 73
        Label9.Text = "Cep Telefonu:"
        '
        'Label10
        '
        Label10.AutoSize = True
        Label10.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label10.Location = New System.Drawing.Point(40, 276)
        Label10.Name = "Label10"
        Label10.Size = New System.Drawing.Size(41, 17)
        Label10.TabIndex = 74
        Label10.Text = "E-mail:"
        '
        'Label11
        '
        Label11.AutoSize = True
        Label11.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label11.Location = New System.Drawing.Point(40, 305)
        Label11.Name = "Label11"
        Label11.Size = New System.Drawing.Size(42, 17)
        Label11.TabIndex = 75
        Label11.Text = "Adres:"
        '
        'Label12
        '
        Label12.AutoSize = True
        Label12.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label12.Location = New System.Drawing.Point(40, 357)
        Label12.Name = "Label12"
        Label12.Size = New System.Drawing.Size(60, 17)
        Label12.TabIndex = 76
        Label12.Text = "Ehliyet No:"
        '
        'Label13
        '
        Label13.AutoSize = True
        Label13.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label13.Location = New System.Drawing.Point(40, 385)
        Label13.Name = "Label13"
        Label13.Size = New System.Drawing.Size(77, 17)
        Label13.TabIndex = 77
        Label13.Text = "Ehliyet Tarihi:"
        '
        'Label14
        '
        Label14.AutoSize = True
        Label14.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label14.Location = New System.Drawing.Point(40, 413)
        Label14.Name = "Label14"
        Label14.Size = New System.Drawing.Size(105, 17)
        Label14.TabIndex = 78
        Label14.Text = "Ehliyet Verilen Yer:"
        '
        'Surucu_AdiLabel
        '
        Surucu_AdiLabel.AutoSize = True
        Surucu_AdiLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Surucu_AdiLabel.Location = New System.Drawing.Point(405, 44)
        Surucu_AdiLabel.Name = "Surucu_AdiLabel"
        Surucu_AdiLabel.Size = New System.Drawing.Size(65, 17)
        Surucu_AdiLabel.TabIndex = 79
        Surucu_AdiLabel.Text = "Surucu Adi:"
        '
        'Kefil_AdLabel
        '
        Kefil_AdLabel.AutoSize = True
        Kefil_AdLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Kefil_AdLabel.Location = New System.Drawing.Point(405, 70)
        Kefil_AdLabel.Name = "Kefil_AdLabel"
        Kefil_AdLabel.Size = New System.Drawing.Size(49, 17)
        Kefil_AdLabel.TabIndex = 80
        Kefil_AdLabel.Text = "Kefil Ad:"
        '
        'Kefil_SoyadLabel
        '
        Kefil_SoyadLabel.AutoSize = True
        Kefil_SoyadLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Kefil_SoyadLabel.Location = New System.Drawing.Point(405, 96)
        Kefil_SoyadLabel.Name = "Kefil_SoyadLabel"
        Kefil_SoyadLabel.Size = New System.Drawing.Size(66, 17)
        Kefil_SoyadLabel.TabIndex = 81
        Kefil_SoyadLabel.Text = "Kefil Soyad:"
        '
        'Kefil_AdresLabel
        '
        Kefil_AdresLabel.AutoSize = True
        Kefil_AdresLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Kefil_AdresLabel.Location = New System.Drawing.Point(405, 122)
        Kefil_AdresLabel.Name = "Kefil_AdresLabel"
        Kefil_AdresLabel.Size = New System.Drawing.Size(67, 17)
        Kefil_AdresLabel.TabIndex = 82
        Kefil_AdresLabel.Text = "Kefil Adres:"
        '
        'Kefil_TelefonLabel
        '
        Kefil_TelefonLabel.AutoSize = True
        Kefil_TelefonLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Kefil_TelefonLabel.Location = New System.Drawing.Point(405, 191)
        Kefil_TelefonLabel.Name = "Kefil_TelefonLabel"
        Kefil_TelefonLabel.Size = New System.Drawing.Size(73, 17)
        Kefil_TelefonLabel.TabIndex = 83
        Kefil_TelefonLabel.Text = "Kefil Telefon:"
        '
        'Kefil_Cep_TelefonuLabel
        '
        Kefil_Cep_TelefonuLabel.AutoSize = True
        Kefil_Cep_TelefonuLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Kefil_Cep_TelefonuLabel.Location = New System.Drawing.Point(405, 214)
        Kefil_Cep_TelefonuLabel.Name = "Kefil_Cep_TelefonuLabel"
        Kefil_Cep_TelefonuLabel.Size = New System.Drawing.Size(99, 17)
        Kefil_Cep_TelefonuLabel.TabIndex = 84
        Kefil_Cep_TelefonuLabel.Text = "Kefil Cep Telefonu:"
        '
        'Label15
        '
        Label15.AutoSize = True
        Label15.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label15.Location = New System.Drawing.Point(776, 44)
        Label15.Name = "Label15"
        Label15.Size = New System.Drawing.Size(61, 17)
        Label15.TabIndex = 86
        Label15.Text = "Araç Ekle :"
        '
        'PlakaLabel
        '
        PlakaLabel.AutoSize = True
        PlakaLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        PlakaLabel.Location = New System.Drawing.Point(776, 65)
        PlakaLabel.Name = "PlakaLabel"
        PlakaLabel.Size = New System.Drawing.Size(39, 17)
        PlakaLabel.TabIndex = 85
        PlakaLabel.Text = "Plaka:"
        '
        'MarkaLabel
        '
        MarkaLabel.AutoSize = True
        MarkaLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        MarkaLabel.Location = New System.Drawing.Point(776, 91)
        MarkaLabel.Name = "MarkaLabel"
        MarkaLabel.Size = New System.Drawing.Size(45, 17)
        MarkaLabel.TabIndex = 87
        MarkaLabel.Text = "Marka:"
        '
        'TipLabel
        '
        TipLabel.AutoSize = True
        TipLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        TipLabel.Location = New System.Drawing.Point(776, 117)
        TipLabel.Name = "TipLabel"
        TipLabel.Size = New System.Drawing.Size(26, 17)
        TipLabel.TabIndex = 88
        TipLabel.Text = "Tip:"
        '
        'ModelLabel
        '
        ModelLabel.AutoSize = True
        ModelLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        ModelLabel.Location = New System.Drawing.Point(776, 143)
        ModelLabel.Name = "ModelLabel"
        ModelLabel.Size = New System.Drawing.Size(41, 17)
        ModelLabel.TabIndex = 89
        ModelLabel.Text = "Model:"
        '
        'RenkLabel
        '
        RenkLabel.AutoSize = True
        RenkLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        RenkLabel.Location = New System.Drawing.Point(776, 169)
        RenkLabel.Name = "RenkLabel"
        RenkLabel.Size = New System.Drawing.Size(36, 17)
        RenkLabel.TabIndex = 90
        RenkLabel.Text = "Renk:"
        '
        'GünlükLabel
        '
        GünlükLabel.AutoSize = True
        GünlükLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        GünlükLabel.Location = New System.Drawing.Point(776, 195)
        GünlükLabel.Name = "GünlükLabel"
        GünlükLabel.Size = New System.Drawing.Size(45, 17)
        GünlükLabel.TabIndex = 91
        GünlükLabel.Text = "Günlük:"
        '
        'HaftalıkLabel
        '
        HaftalıkLabel.AutoSize = True
        HaftalıkLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        HaftalıkLabel.Location = New System.Drawing.Point(776, 221)
        HaftalıkLabel.Name = "HaftalıkLabel"
        HaftalıkLabel.Size = New System.Drawing.Size(51, 17)
        HaftalıkLabel.TabIndex = 92
        HaftalıkLabel.Text = "Haftalık:"
        '
        'AylıkLabel
        '
        AylıkLabel.AutoSize = True
        AylıkLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        AylıkLabel.Location = New System.Drawing.Point(776, 247)
        AylıkLabel.Name = "AylıkLabel"
        AylıkLabel.Size = New System.Drawing.Size(37, 17)
        AylıkLabel.TabIndex = 93
        AylıkLabel.Text = "Aylık:"
        '
        'Çıkış_ZamanıLabel
        '
        Çıkış_ZamanıLabel.AutoSize = True
        Çıkış_ZamanıLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Çıkış_ZamanıLabel.Location = New System.Drawing.Point(776, 275)
        Çıkış_ZamanıLabel.Name = "Çıkış_ZamanıLabel"
        Çıkış_ZamanıLabel.Size = New System.Drawing.Size(74, 17)
        Çıkış_ZamanıLabel.TabIndex = 94
        Çıkış_ZamanıLabel.Text = "Çıkış Zamanı:"
        '
        'Dönüş_ZamanıLabel
        '
        Dönüş_ZamanıLabel.AutoSize = True
        Dönüş_ZamanıLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Dönüş_ZamanıLabel.Location = New System.Drawing.Point(776, 301)
        Dönüş_ZamanıLabel.Name = "Dönüş_ZamanıLabel"
        Dönüş_ZamanıLabel.Size = New System.Drawing.Size(79, 17)
        Dönüş_ZamanıLabel.TabIndex = 95
        Dönüş_ZamanıLabel.Text = "Dönüş Zamanı:"
        '
        'Ek_TutarLabel
        '
        Ek_TutarLabel.AutoSize = True
        Ek_TutarLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Ek_TutarLabel.Location = New System.Drawing.Point(776, 325)
        Ek_TutarLabel.Name = "Ek_TutarLabel"
        Ek_TutarLabel.Size = New System.Drawing.Size(54, 17)
        Ek_TutarLabel.TabIndex = 96
        Ek_TutarLabel.Text = "Ek Tutar:"
        '
        'ToplamLabel
        '
        ToplamLabel.AutoSize = True
        ToplamLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        ToplamLabel.Location = New System.Drawing.Point(776, 351)
        ToplamLabel.Name = "ToplamLabel"
        ToplamLabel.Size = New System.Drawing.Size(47, 17)
        ToplamLabel.TabIndex = 97
        ToplamLabel.Text = "Toplam:"
        '
        'AcıklamaLabel
        '
        AcıklamaLabel.AutoSize = True
        AcıklamaLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        AcıklamaLabel.Location = New System.Drawing.Point(776, 377)
        AcıklamaLabel.Name = "AcıklamaLabel"
        AcıklamaLabel.Size = New System.Drawing.Size(58, 17)
        AcıklamaLabel.TabIndex = 98
        AcıklamaLabel.Text = "Acıklama:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label2.Location = New System.Drawing.Point(41, 147)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(49, 17)
        Label2.TabIndex = 101
        Label2.Text = "Cinsiyet"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(153, 41)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 99
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"Bay", "Bayan"})
        Me.ComboBox2.Location = New System.Drawing.Point(153, 144)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox2.TabIndex = 100
        Me.ComboBox2.Text = "Bay"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(153, 65)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 102
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(153, 92)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 103
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(153, 118)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 104
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(153, 171)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 105
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(153, 198)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 106
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(153, 224)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 107
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(153, 250)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 108
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(153, 276)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 109
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(153, 302)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 110
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(153, 356)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 20)
        Me.TextBox9.TabIndex = 111
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(153, 410)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 20)
        Me.TextBox10.TabIndex = 112
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(517, 42)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(100, 20)
        Me.TextBox11.TabIndex = 113
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(153, 384)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker2.TabIndex = 114
        '
        'TextBox12
        '
        Me.TextBox12.Location = New System.Drawing.Point(517, 67)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(100, 20)
        Me.TextBox12.TabIndex = 115
        '
        'TextBox13
        '
        Me.TextBox13.Location = New System.Drawing.Point(517, 93)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(100, 20)
        Me.TextBox13.TabIndex = 116
        '
        'TextBox14
        '
        Me.TextBox14.Location = New System.Drawing.Point(517, 123)
        Me.TextBox14.Multiline = True
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(198, 56)
        Me.TextBox14.TabIndex = 117
        '
        'TextBox15
        '
        Me.TextBox15.Location = New System.Drawing.Point(517, 185)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(100, 20)
        Me.TextBox15.TabIndex = 118
        '
        'TextBox16
        '
        Me.TextBox16.Location = New System.Drawing.Point(517, 211)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(100, 20)
        Me.TextBox16.TabIndex = 119
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(867, 43)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox3.TabIndex = 120
        '
        'TextBox17
        '
        Me.TextBox17.Location = New System.Drawing.Point(867, 66)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(100, 20)
        Me.TextBox17.TabIndex = 121
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(867, 89)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(100, 20)
        Me.TextBox18.TabIndex = 122
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(867, 115)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(100, 20)
        Me.TextBox19.TabIndex = 123
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(867, 144)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(100, 20)
        Me.TextBox20.TabIndex = 124
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(867, 170)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(100, 20)
        Me.TextBox21.TabIndex = 125
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(867, 197)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(100, 20)
        Me.TextBox22.TabIndex = 126
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(867, 219)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(100, 20)
        Me.TextBox23.TabIndex = 127
        '
        'DateTimePicker3
        '
        Me.DateTimePicker3.Location = New System.Drawing.Point(867, 271)
        Me.DateTimePicker3.Name = "DateTimePicker3"
        Me.DateTimePicker3.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker3.TabIndex = 132
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(867, 245)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(100, 20)
        Me.TextBox24.TabIndex = 133
        '
        'DateTimePicker4
        '
        Me.DateTimePicker4.Location = New System.Drawing.Point(867, 297)
        Me.DateTimePicker4.Name = "DateTimePicker4"
        Me.DateTimePicker4.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker4.TabIndex = 134
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(867, 323)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(100, 20)
        Me.TextBox25.TabIndex = 136
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(867, 349)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(100, 20)
        Me.TextBox26.TabIndex = 137
        '
        'TextBox27
        '
        Me.TextBox27.Location = New System.Drawing.Point(867, 375)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(100, 20)
        Me.TextBox27.TabIndex = 138
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Orange
        Me.Button7.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button7.Location = New System.Drawing.Point(1036, 114)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(169, 28)
        Me.Button7.TabIndex = 144
        Me.Button7.Text = "Çıkış"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Orange
        Me.Button3.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button3.Location = New System.Drawing.Point(1039, 46)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(166, 28)
        Me.Button3.TabIndex = 141
        Me.Button3.Text = "Sil"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Orange
        Me.Button2.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button2.Location = New System.Drawing.Point(1039, 80)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(166, 28)
        Me.Button2.TabIndex = 140
        Me.Button2.Text = "Kirala"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(44, 462)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1137, 278)
        Me.DataGridView1.TabIndex = 145
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Orange
        Me.Button6.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button6.Location = New System.Drawing.Point(1039, 413)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(142, 28)
        Me.Button6.TabIndex = 146
        Me.Button6.Text = "Teslim Al"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1231, 763)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox27)
        Me.Controls.Add(Me.TextBox26)
        Me.Controls.Add(Me.TextBox25)
        Me.Controls.Add(Me.DateTimePicker4)
        Me.Controls.Add(Me.TextBox24)
        Me.Controls.Add(Me.DateTimePicker3)
        Me.Controls.Add(Me.TextBox23)
        Me.Controls.Add(Me.TextBox22)
        Me.Controls.Add(Me.TextBox21)
        Me.Controls.Add(Me.TextBox20)
        Me.Controls.Add(Me.TextBox19)
        Me.Controls.Add(Me.TextBox18)
        Me.Controls.Add(Me.TextBox17)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Label4)
        Me.Controls.Add(Label5)
        Me.Controls.Add(Label6)
        Me.Controls.Add(Label7)
        Me.Controls.Add(Label8)
        Me.Controls.Add(Label9)
        Me.Controls.Add(Label10)
        Me.Controls.Add(Label11)
        Me.Controls.Add(Label12)
        Me.Controls.Add(Label13)
        Me.Controls.Add(Label14)
        Me.Controls.Add(Surucu_AdiLabel)
        Me.Controls.Add(Kefil_AdLabel)
        Me.Controls.Add(Kefil_SoyadLabel)
        Me.Controls.Add(Kefil_AdresLabel)
        Me.Controls.Add(Kefil_TelefonLabel)
        Me.Controls.Add(Kefil_Cep_TelefonuLabel)
        Me.Controls.Add(Label15)
        Me.Controls.Add(PlakaLabel)
        Me.Controls.Add(MarkaLabel)
        Me.Controls.Add(TipLabel)
        Me.Controls.Add(ModelLabel)
        Me.Controls.Add(RenkLabel)
        Me.Controls.Add(GünlükLabel)
        Me.Controls.Add(HaftalıkLabel)
        Me.Controls.Add(AylıkLabel)
        Me.Controls.Add(Çıkış_ZamanıLabel)
        Me.Controls.Add(Dönüş_ZamanıLabel)
        Me.Controls.Add(Ek_TutarLabel)
        Me.Controls.Add(ToplamLabel)
        Me.Controls.Add(AcıklamaLabel)
        Me.Name = "Form4"
        Me.Text = "Form4"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker3 As System.Windows.Forms.DateTimePicker
    Public WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Public WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker4 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox27 As System.Windows.Forms.TextBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Public WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button6 As System.Windows.Forms.Button
End Class
