﻿Public Class Form5
    'www.gorselprogramlama.com
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text.Trim() <> "" Then
            Form2.bag.Open()  'form1'deki metni kapat
            Form2.kmt.Connection = Form2.bag 'komurun bağlantısı form1'deki bag değişkeni
            'kmt.CommandText = "INSERT INTO musbil(TcKimlikNo,Ad,Soyad,Cinsiyet,DogumTarihi,DogumYeri,Telefon,CepTel,Email,Adres,EhliyetNo,EhliyetTarihi,EhliyetVerilenYer) VALUES ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & ComboBox1.Text & "','" & DateTimePicker1.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "','" & DateTimePicker2.Text & "','" & TextBox10.Text & "') "
            'kmt.ExecuteNonQuery()
            Form2.kmt.CommandText = "UPDATE musbil SET TcKimlikNo='" & TextBox1.Text & "',Ad='" & TextBox2.Text & "',Soyad='" & TextBox3.Text & "',Cinsiyet='" & ComboBox1.Text & "',DogumTarihi='" & DateTimePicker1.Text & "',DogumYeri='" & TextBox4.Text & "',Telefon='" & TextBox5.Text & "',CepTel='" & TextBox6.Text & "',Email='" & TextBox7.Text & "',Adres='" & TextBox8.Text & "',EhliyetNo='" & TextBox9.Text & "',EhliyetTarihi='" & DateTimePicker2.Text & "',EhliyetVerilenYer='" & TextBox10.Text & "' WHERE TcKimlikNo='" & Form2.DataGridView1.CurrentRow.Cells(0).Value.ToString() & "' " 'güncelleme sorgu metni
            Form2.kmt.ExecuteNonQuery() 'sorguyu çalıştır.
            Form2.kmt.Dispose() 'Komut kullanımını kapatıyoruz.
            Form2.bag.Close() 'veritabanımızı kapatıyoruz.
            Form2.listele() 'form1'deki listele prosedürünü çalıştır.
            Me.Close() 'aktif formu kapat.
        Else 'www.gorselprogramlama.com
            MessageBox.Show("Tckimlik alanını boş bırakmayınız !!!") 'değilse mesajı yaz
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close() 'www.gorselprogramlama.com
    End Sub

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class