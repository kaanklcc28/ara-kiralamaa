﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.MüşteriToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MüsteriTablosuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AraçToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AraçTablosuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SözleşmeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.YeniSözleşmeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SözleşmeBelgesiToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AyarlarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.YardımToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ÇıkışToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Orange
        Me.MenuStrip1.Font = New System.Drawing.Font("Haettenschweiler", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MüşteriToolStripMenuItem, Me.AraçToolStripMenuItem, Me.SözleşmeToolStripMenuItem, Me.AyarlarToolStripMenuItem, Me.YardımToolStripMenuItem, Me.ÇıkışToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1267, 29)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'MüşteriToolStripMenuItem
        '
        Me.MüşteriToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MüsteriTablosuToolStripMenuItem})
        Me.MüşteriToolStripMenuItem.Name = "MüşteriToolStripMenuItem"
        Me.MüşteriToolStripMenuItem.Size = New System.Drawing.Size(70, 25)
        Me.MüşteriToolStripMenuItem.Text = "Müşteri"
        '
        'MüsteriTablosuToolStripMenuItem
        '
        Me.MüsteriTablosuToolStripMenuItem.Name = "MüsteriTablosuToolStripMenuItem"
        Me.MüsteriTablosuToolStripMenuItem.Size = New System.Drawing.Size(176, 26)
        Me.MüsteriTablosuToolStripMenuItem.Text = "Müsteri Tablosu"
        '
        'AraçToolStripMenuItem
        '
        Me.AraçToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AraçTablosuToolStripMenuItem})
        Me.AraçToolStripMenuItem.Name = "AraçToolStripMenuItem"
        Me.AraçToolStripMenuItem.Size = New System.Drawing.Size(51, 25)
        Me.AraçToolStripMenuItem.Text = "Araç"
        '
        'AraçTablosuToolStripMenuItem
        '
        Me.AraçTablosuToolStripMenuItem.Name = "AraçTablosuToolStripMenuItem"
        Me.AraçTablosuToolStripMenuItem.Size = New System.Drawing.Size(157, 26)
        Me.AraçTablosuToolStripMenuItem.Text = "Araç Tablosu"
        '
        'SözleşmeToolStripMenuItem
        '
        Me.SözleşmeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.YeniSözleşmeToolStripMenuItem, Me.SözleşmeBelgesiToolStripMenuItem})
        Me.SözleşmeToolStripMenuItem.Name = "SözleşmeToolStripMenuItem"
        Me.SözleşmeToolStripMenuItem.Size = New System.Drawing.Size(78, 25)
        Me.SözleşmeToolStripMenuItem.Text = "Sözleşme"
        '
        'YeniSözleşmeToolStripMenuItem
        '
        Me.YeniSözleşmeToolStripMenuItem.Name = "YeniSözleşmeToolStripMenuItem"
        Me.YeniSözleşmeToolStripMenuItem.Size = New System.Drawing.Size(180, 26)
        Me.YeniSözleşmeToolStripMenuItem.Text = "Yeni Sözleşme"
        '
        'SözleşmeBelgesiToolStripMenuItem
        '
        Me.SözleşmeBelgesiToolStripMenuItem.Name = "SözleşmeBelgesiToolStripMenuItem"
        Me.SözleşmeBelgesiToolStripMenuItem.Size = New System.Drawing.Size(180, 26)
        Me.SözleşmeBelgesiToolStripMenuItem.Text = "Sözleşme Belgesi"
        '
        'AyarlarToolStripMenuItem
        '
        Me.AyarlarToolStripMenuItem.Name = "AyarlarToolStripMenuItem"
        Me.AyarlarToolStripMenuItem.Size = New System.Drawing.Size(68, 25)
        Me.AyarlarToolStripMenuItem.Text = "Ayarlar"
        '
        'YardımToolStripMenuItem
        '
        Me.YardımToolStripMenuItem.Name = "YardımToolStripMenuItem"
        Me.YardımToolStripMenuItem.Size = New System.Drawing.Size(65, 25)
        Me.YardımToolStripMenuItem.Text = "Yardım"
        '
        'ÇıkışToolStripMenuItem
        '
        Me.ÇıkışToolStripMenuItem.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ÇıkışToolStripMenuItem.Name = "ÇıkışToolStripMenuItem"
        Me.ÇıkışToolStripMenuItem.Size = New System.Drawing.Size(50, 25)
        Me.ÇıkışToolStripMenuItem.Text = "Çıkış"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Haettenschweiler", 68.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(302, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(678, 95)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Rent-a Car Otomasyon"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-12, 140)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1444, 644)
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1267, 782)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents MüşteriToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MüsteriTablosuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AraçToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AraçTablosuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SözleşmeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents YeniSözleşmeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SözleşmeBelgesiToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AyarlarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents YardımToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ÇıkışToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox

End Class
