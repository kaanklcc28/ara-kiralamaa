﻿Public Class Form1 'www.gorselprogramlama.com



    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub MüsteriTablosuToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MüsteriTablosuToolStripMenuItem.Click
        Form2.Show()
    End Sub
    Private Sub YeniSözleşmeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub AraçTablosuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub MüsteriTablosuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AraçTablosuToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AraçTablosuToolStripMenuItem.Click
        Form3.Show()
    End Sub

    Private Sub YeniSözleşmeToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles YeniSözleşmeToolStripMenuItem.Click
        Form4.Show() 'www.gorselprogramlama.com
    End Sub

    Private Sub ÇıkışToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ÇıkışToolStripMenuItem.Click
        Close()
    End Sub
End Class
