﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Label1 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Label3 As System.Windows.Forms.Label
        Dim Label4 As System.Windows.Forms.Label
        Dim Label5 As System.Windows.Forms.Label
        Dim GünlükLabel As System.Windows.Forms.Label
        Dim HaftalıkLabel As System.Windows.Forms.Label
        Dim AylıkLabel As System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PlakaToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.PlakaToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.PlakaToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.PlakaToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Label1 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Label3 = New System.Windows.Forms.Label()
        Label4 = New System.Windows.Forms.Label()
        Label5 = New System.Windows.Forms.Label()
        GünlükLabel = New System.Windows.Forms.Label()
        HaftalıkLabel = New System.Windows.Forms.Label()
        AylıkLabel = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PlakaToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(120, 40)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 20
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(120, 66)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 21
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(120, 92)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 22
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(120, 118)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 23
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(120, 144)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 24
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(120, 187)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 25
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(120, 214)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 26
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(120, 241)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 27
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(236, 85)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(542, 392)
        Me.DataGridView1.TabIndex = 30
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Orange
        Me.Button7.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button7.Location = New System.Drawing.Point(807, 153)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(160, 26)
        Me.Button7.TabIndex = 87
        Me.Button7.Text = "Çıkış"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Orange
        Me.Button3.Font = New System.Drawing.Font("Haettenschweiler", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button3.Location = New System.Drawing.Point(890, 89)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(77, 27)
        Me.Button3.TabIndex = 84
        Me.Button3.Text = "Sil"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Orange
        Me.Button2.Font = New System.Drawing.Font("Haettenschweiler", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button2.Location = New System.Drawing.Point(807, 122)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(160, 25)
        Me.Button2.TabIndex = 83
        Me.Button2.Text = "Kaydet"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Orange
        Me.Button1.Font = New System.Drawing.Font("Haettenschweiler", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button1.Location = New System.Drawing.Point(807, 88)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(77, 28)
        Me.Button1.TabIndex = 82
        Me.Button1.Text = "Düzenle"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label1.Location = New System.Drawing.Point(36, 40)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(39, 17)
        Label1.TabIndex = 88
        Label1.Text = "Plaka:"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label2.Location = New System.Drawing.Point(36, 66)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(45, 17)
        Label2.TabIndex = 89
        Label2.Text = "Marka:"
        '
        'Label3
        '
        Label3.AutoSize = True
        Label3.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label3.Location = New System.Drawing.Point(36, 92)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(26, 17)
        Label3.TabIndex = 90
        Label3.Text = "Tip:"
        '
        'Label4
        '
        Label4.AutoSize = True
        Label4.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label4.Location = New System.Drawing.Point(36, 118)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(41, 17)
        Label4.TabIndex = 91
        Label4.Text = "Model:"
        '
        'Label5
        '
        Label5.AutoSize = True
        Label5.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label5.Location = New System.Drawing.Point(36, 144)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(36, 17)
        Label5.TabIndex = 92
        Label5.Text = "Renk:"
        '
        'GünlükLabel
        '
        GünlükLabel.AutoSize = True
        GünlükLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        GünlükLabel.Location = New System.Drawing.Point(36, 189)
        GünlükLabel.Name = "GünlükLabel"
        GünlükLabel.Size = New System.Drawing.Size(45, 17)
        GünlükLabel.TabIndex = 93
        GünlükLabel.Text = "Günlük:"
        '
        'HaftalıkLabel
        '
        HaftalıkLabel.AutoSize = True
        HaftalıkLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        HaftalıkLabel.Location = New System.Drawing.Point(36, 215)
        HaftalıkLabel.Name = "HaftalıkLabel"
        HaftalıkLabel.Size = New System.Drawing.Size(51, 17)
        HaftalıkLabel.TabIndex = 94
        HaftalıkLabel.Text = "Haftalık:"
        '
        'AylıkLabel
        '
        AylıkLabel.AutoSize = True
        AylıkLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        AylıkLabel.Location = New System.Drawing.Point(36, 241)
        AylıkLabel.Name = "AylıkLabel"
        AylıkLabel.Size = New System.Drawing.Size(37, 17)
        AylıkLabel.TabIndex = 95
        AylıkLabel.Text = "Aylık:"
        '
        'PlakaToolStrip1
        '
        Me.PlakaToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.PlakaToolStrip1.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.PlakaToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PlakaToolStripLabel1, Me.PlakaToolStripTextBox1, Me.PlakaToolStripButton1})
        Me.PlakaToolStrip1.Location = New System.Drawing.Point(297, 40)
        Me.PlakaToolStrip1.Name = "PlakaToolStrip1"
        Me.PlakaToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.PlakaToolStrip1.Size = New System.Drawing.Size(265, 25)
        Me.PlakaToolStrip1.TabIndex = 96
        Me.PlakaToolStrip1.Text = "PlakaToolStrip1"
        '
        'PlakaToolStripLabel1
        '
        Me.PlakaToolStripLabel1.BackColor = System.Drawing.Color.Orange
        Me.PlakaToolStripLabel1.Name = "PlakaToolStripLabel1"
        Me.PlakaToolStripLabel1.Size = New System.Drawing.Size(74, 22)
        Me.PlakaToolStripLabel1.Text = "Araç [Plaka] :"
        '
        'PlakaToolStripTextBox1
        '
        Me.PlakaToolStripTextBox1.Name = "PlakaToolStripTextBox1"
        Me.PlakaToolStripTextBox1.Size = New System.Drawing.Size(150, 25)
        '
        'PlakaToolStripButton1
        '
        Me.PlakaToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.PlakaToolStripButton1.Name = "PlakaToolStripButton1"
        Me.PlakaToolStripButton1.Size = New System.Drawing.Size(27, 22)
        Me.PlakaToolStripButton1.Text = "Bul"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(990, 508)
        Me.Controls.Add(Me.PlakaToolStrip1)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Label3)
        Me.Controls.Add(Label4)
        Me.Controls.Add(Label5)
        Me.Controls.Add(GünlükLabel)
        Me.Controls.Add(HaftalıkLabel)
        Me.Controls.Add(AylıkLabel)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PlakaToolStrip1.ResumeLayout(False)
        Me.PlakaToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Public WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PlakaToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents PlakaToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents PlakaToolStripTextBox1 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents PlakaToolStripButton1 As System.Windows.Forms.ToolStripButton
End Class
