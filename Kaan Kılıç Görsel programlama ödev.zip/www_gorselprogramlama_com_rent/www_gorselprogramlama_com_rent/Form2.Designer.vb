﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Tc_Kimlik_NoLabel As System.Windows.Forms.Label
        Dim SoyadLabel As System.Windows.Forms.Label
        Dim AdLabel As System.Windows.Forms.Label
        Dim Dogum_TarihiLabel As System.Windows.Forms.Label
        Dim Dogum_YeriLabel As System.Windows.Forms.Label
        Dim TelefonLabel As System.Windows.Forms.Label
        Dim Cep_TelefonuLabel As System.Windows.Forms.Label
        Dim E_MailLabel As System.Windows.Forms.Label
        Dim AdresLabel As System.Windows.Forms.Label
        Dim Ehliyet_NoLabel As System.Windows.Forms.Label
        Dim Eliyet_TarihiLabel As System.Windows.Forms.Label
        Dim Ehliyet_Verilen_YerLabel As System.Windows.Forms.Label
        Dim Label1 As System.Windows.Forms.Label
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.SoyadToolStrip = New System.Windows.Forms.ToolStrip()
        Me.TcNumaraToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.TcNumaraToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.TcNumaraToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.Button7 = New System.Windows.Forms.Button()
        Tc_Kimlik_NoLabel = New System.Windows.Forms.Label()
        SoyadLabel = New System.Windows.Forms.Label()
        AdLabel = New System.Windows.Forms.Label()
        Dogum_TarihiLabel = New System.Windows.Forms.Label()
        Dogum_YeriLabel = New System.Windows.Forms.Label()
        TelefonLabel = New System.Windows.Forms.Label()
        Cep_TelefonuLabel = New System.Windows.Forms.Label()
        E_MailLabel = New System.Windows.Forms.Label()
        AdresLabel = New System.Windows.Forms.Label()
        Ehliyet_NoLabel = New System.Windows.Forms.Label()
        Eliyet_TarihiLabel = New System.Windows.Forms.Label()
        Ehliyet_Verilen_YerLabel = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SoyadToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(145, 163)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 51
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(145, 426)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker2.TabIndex = 52
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(145, 47)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 53
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(145, 73)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 54
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(145, 100)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 55
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(145, 189)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 56
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(145, 216)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 57
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(145, 243)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 58
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(145, 270)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 59
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(145, 297)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 60
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(145, 399)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 20)
        Me.TextBox9.TabIndex = 61
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(145, 452)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 20)
        Me.TextBox10.TabIndex = 62
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(364, 88)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(694, 394)
        Me.DataGridView1.TabIndex = 69
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Orange
        Me.Button3.Font = New System.Drawing.Font("Haettenschweiler", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button3.Location = New System.Drawing.Point(470, 40)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(80, 27)
        Me.Button3.TabIndex = 73
        Me.Button3.Text = "Sil"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Orange
        Me.Button2.Font = New System.Drawing.Font("Haettenschweiler", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button2.Location = New System.Drawing.Point(556, 40)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(80, 28)
        Me.Button2.TabIndex = 72
        Me.Button2.Text = "Kaydet"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Orange
        Me.Button1.Font = New System.Drawing.Font("Haettenschweiler", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button1.Location = New System.Drawing.Point(364, 39)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(100, 28)
        Me.Button1.TabIndex = 71
        Me.Button1.Text = "Düzenle"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Tc_Kimlik_NoLabel
        '
        Tc_Kimlik_NoLabel.AutoSize = True
        Tc_Kimlik_NoLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Tc_Kimlik_NoLabel.Location = New System.Drawing.Point(29, 50)
        Tc_Kimlik_NoLabel.Name = "Tc_Kimlik_NoLabel"
        Tc_Kimlik_NoLabel.Size = New System.Drawing.Size(72, 17)
        Tc_Kimlik_NoLabel.TabIndex = 74
        Tc_Kimlik_NoLabel.Text = "Tc Kimlik No:"
        '
        'SoyadLabel
        '
        SoyadLabel.AutoSize = True
        SoyadLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        SoyadLabel.Location = New System.Drawing.Point(29, 103)
        SoyadLabel.Name = "SoyadLabel"
        SoyadLabel.Size = New System.Drawing.Size(41, 17)
        SoyadLabel.TabIndex = 76
        SoyadLabel.Text = "Soyad:"
        '
        'AdLabel
        '
        AdLabel.AutoSize = True
        AdLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        AdLabel.Location = New System.Drawing.Point(29, 77)
        AdLabel.Name = "AdLabel"
        AdLabel.Size = New System.Drawing.Size(24, 17)
        AdLabel.TabIndex = 75
        AdLabel.Text = "Ad:"
        '
        'Dogum_TarihiLabel
        '
        Dogum_TarihiLabel.AutoSize = True
        Dogum_TarihiLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Dogum_TarihiLabel.Location = New System.Drawing.Point(29, 172)
        Dogum_TarihiLabel.Name = "Dogum_TarihiLabel"
        Dogum_TarihiLabel.Size = New System.Drawing.Size(76, 17)
        Dogum_TarihiLabel.TabIndex = 77
        Dogum_TarihiLabel.Text = "Dogum Tarihi:"
        '
        'Dogum_YeriLabel
        '
        Dogum_YeriLabel.AutoSize = True
        Dogum_YeriLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Dogum_YeriLabel.Location = New System.Drawing.Point(29, 198)
        Dogum_YeriLabel.Name = "Dogum_YeriLabel"
        Dogum_YeriLabel.Size = New System.Drawing.Size(68, 17)
        Dogum_YeriLabel.TabIndex = 78
        Dogum_YeriLabel.Text = "Dogum Yeri:"
        '
        'TelefonLabel
        '
        TelefonLabel.AutoSize = True
        TelefonLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        TelefonLabel.Location = New System.Drawing.Point(29, 224)
        TelefonLabel.Name = "TelefonLabel"
        TelefonLabel.Size = New System.Drawing.Size(48, 17)
        TelefonLabel.TabIndex = 79
        TelefonLabel.Text = "Telefon:"
        '
        'Cep_TelefonuLabel
        '
        Cep_TelefonuLabel.AutoSize = True
        Cep_TelefonuLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Cep_TelefonuLabel.Location = New System.Drawing.Point(29, 250)
        Cep_TelefonuLabel.Name = "Cep_TelefonuLabel"
        Cep_TelefonuLabel.Size = New System.Drawing.Size(74, 17)
        Cep_TelefonuLabel.TabIndex = 80
        Cep_TelefonuLabel.Text = "Cep Telefonu:"
        '
        'E_MailLabel
        '
        E_MailLabel.AutoSize = True
        E_MailLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        E_MailLabel.Location = New System.Drawing.Point(29, 276)
        E_MailLabel.Name = "E_MailLabel"
        E_MailLabel.Size = New System.Drawing.Size(41, 17)
        E_MailLabel.TabIndex = 81
        E_MailLabel.Text = "E-Mail:"
        '
        'AdresLabel
        '
        AdresLabel.AutoSize = True
        AdresLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        AdresLabel.Location = New System.Drawing.Point(29, 302)
        AdresLabel.Name = "AdresLabel"
        AdresLabel.Size = New System.Drawing.Size(42, 17)
        AdresLabel.TabIndex = 82
        AdresLabel.Text = "Adres:"
        '
        'Ehliyet_NoLabel
        '
        Ehliyet_NoLabel.AutoSize = True
        Ehliyet_NoLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Ehliyet_NoLabel.Location = New System.Drawing.Point(29, 402)
        Ehliyet_NoLabel.Name = "Ehliyet_NoLabel"
        Ehliyet_NoLabel.Size = New System.Drawing.Size(60, 17)
        Ehliyet_NoLabel.TabIndex = 83
        Ehliyet_NoLabel.Text = "Ehliyet No:"
        '
        'Eliyet_TarihiLabel
        '
        Eliyet_TarihiLabel.AutoSize = True
        Eliyet_TarihiLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Eliyet_TarihiLabel.Location = New System.Drawing.Point(29, 428)
        Eliyet_TarihiLabel.Name = "Eliyet_TarihiLabel"
        Eliyet_TarihiLabel.Size = New System.Drawing.Size(71, 17)
        Eliyet_TarihiLabel.TabIndex = 84
        Eliyet_TarihiLabel.Text = "Eliyet Tarihi:"
        '
        'Ehliyet_Verilen_YerLabel
        '
        Ehliyet_Verilen_YerLabel.AutoSize = True
        Ehliyet_Verilen_YerLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Ehliyet_Verilen_YerLabel.Location = New System.Drawing.Point(29, 454)
        Ehliyet_Verilen_YerLabel.Name = "Ehliyet_Verilen_YerLabel"
        Ehliyet_Verilen_YerLabel.Size = New System.Drawing.Size(105, 17)
        Ehliyet_Verilen_YerLabel.TabIndex = 85
        Ehliyet_Verilen_YerLabel.Text = "Ehliyet Verilen Yer:"
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label1.Location = New System.Drawing.Point(29, 134)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(49, 17)
        Label1.TabIndex = 86
        Label1.Text = "Cinsiyet"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Bay", "Bayan"})
        Me.ComboBox1.Location = New System.Drawing.Point(145, 130)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 87
        Me.ComboBox1.Text = "Bay"
        '
        'SoyadToolStrip
        '
        Me.SoyadToolStrip.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SoyadToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.SoyadToolStrip.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.SoyadToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TcNumaraToolStripLabel, Me.TcNumaraToolStripTextBox, Me.TcNumaraToolStripButton})
        Me.SoyadToolStrip.Location = New System.Drawing.Point(681, 43)
        Me.SoyadToolStrip.Name = "SoyadToolStrip"
        Me.SoyadToolStrip.Size = New System.Drawing.Size(293, 25)
        Me.SoyadToolStrip.TabIndex = 88
        Me.SoyadToolStrip.Text = "TcNumaraToolStrip"
        '
        'TcNumaraToolStripLabel
        '
        Me.TcNumaraToolStripLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None
        Me.TcNumaraToolStripLabel.Enabled = False
        Me.TcNumaraToolStripLabel.Name = "TcNumaraToolStripLabel"
        Me.TcNumaraToolStripLabel.Size = New System.Drawing.Size(0, 22)
        Me.TcNumaraToolStripLabel.Text = "TcNumara:"
        '
        'TcNumaraToolStripTextBox
        '
        Me.TcNumaraToolStripTextBox.Name = "TcNumaraToolStripTextBox"
        Me.TcNumaraToolStripTextBox.Size = New System.Drawing.Size(200, 25)
        '
        'TcNumaraToolStripButton
        '
        Me.TcNumaraToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.TcNumaraToolStripButton.Name = "TcNumaraToolStripButton"
        Me.TcNumaraToolStripButton.Size = New System.Drawing.Size(79, 22)
        Me.TcNumaraToolStripButton.Text = "Tc Kimlik Ara"
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Orange
        Me.Button7.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button7.Location = New System.Drawing.Point(995, 45)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(63, 27)
        Me.Button7.TabIndex = 89
        Me.Button7.Text = "Çıkış"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1079, 525)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.SoyadToolStrip)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Tc_Kimlik_NoLabel)
        Me.Controls.Add(SoyadLabel)
        Me.Controls.Add(AdLabel)
        Me.Controls.Add(Dogum_TarihiLabel)
        Me.Controls.Add(Dogum_YeriLabel)
        Me.Controls.Add(TelefonLabel)
        Me.Controls.Add(Cep_TelefonuLabel)
        Me.Controls.Add(E_MailLabel)
        Me.Controls.Add(AdresLabel)
        Me.Controls.Add(Ehliyet_NoLabel)
        Me.Controls.Add(Eliyet_TarihiLabel)
        Me.Controls.Add(Ehliyet_Verilen_YerLabel)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Name = "Form2"
        Me.Text = "Form2"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SoyadToolStrip.ResumeLayout(False)
        Me.SoyadToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents SoyadToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents TcNumaraToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents TcNumaraToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents TcNumaraToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents Button7 As System.Windows.Forms.Button
End Class
