﻿Public Class Form6
    'www.gorselprogramlama.com
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text.Trim() <> "" Then
            Form2.bag.Open()  'form1'deki metni kapat
            Form2.kmt.Connection = Form2.bag 'komurun bağlantısı form1'deki bag değişkeni
            'Form2.kmt.CommandText = "INSERT INTO aracbil(Plaka,Marka,Tip,Model,Renk,Gunluk,Haftalik,Aylik,Durum) VALUES ('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','Uygun') "
            'Form2.kmt.ExecuteNonQuery()
            Form2.kmt.CommandText = "UPDATE aracbil SET Plaka='" & TextBox1.Text & "',Marka='" & TextBox2.Text & "',Tip='" & TextBox3.Text & "',Model='" & TextBox4.Text & "',Renk='" & TextBox5.Text & "',Gunluk='" & TextBox6.Text & "',Haftalik='" & TextBox7.Text & "',Aylik='" & TextBox8.Text & "' WHERE Plaka='" & Form3.DataGridView1.CurrentRow.Cells(0).Value.ToString() & "' " 'güncelleme sorgu metni
            Form2.kmt.ExecuteNonQuery() 'sorguyu çalıştır.
            Form2.kmt.Dispose() 'Komut kullanımını kapatıyoruz.
            Form2.bag.Close() 'veritabanımızı kapatıyoruz.
            Form2.aracListele() 'www.gorselprogramlama.com
            Me.Close() 'aktif formu kapat.
        Else
            MessageBox.Show("Tckimlik alanını boş bırakmayınız !!!") 'değilse mesajı yaz
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close() 'www.gorselprogramlama.com
    End Sub

    Private Sub Form6_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class