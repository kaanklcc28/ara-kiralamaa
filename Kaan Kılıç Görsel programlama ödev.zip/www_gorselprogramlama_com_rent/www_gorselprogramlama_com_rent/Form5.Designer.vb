﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form5
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Label1 As System.Windows.Forms.Label
        Dim Tc_Kimlik_NoLabel As System.Windows.Forms.Label
        Dim SoyadLabel As System.Windows.Forms.Label
        Dim AdLabel As System.Windows.Forms.Label
        Dim Dogum_TarihiLabel As System.Windows.Forms.Label
        Dim Dogum_YeriLabel As System.Windows.Forms.Label
        Dim TelefonLabel As System.Windows.Forms.Label
        Dim Cep_TelefonuLabel As System.Windows.Forms.Label
        Dim E_MailLabel As System.Windows.Forms.Label
        Dim AdresLabel As System.Windows.Forms.Label
        Dim Ehliyet_NoLabel As System.Windows.Forms.Label
        Dim Eliyet_TarihiLabel As System.Windows.Forms.Label
        Dim Ehliyet_Verilen_YerLabel As System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Label1 = New System.Windows.Forms.Label()
        Tc_Kimlik_NoLabel = New System.Windows.Forms.Label()
        SoyadLabel = New System.Windows.Forms.Label()
        AdLabel = New System.Windows.Forms.Label()
        Dogum_TarihiLabel = New System.Windows.Forms.Label()
        Dogum_YeriLabel = New System.Windows.Forms.Label()
        TelefonLabel = New System.Windows.Forms.Label()
        Cep_TelefonuLabel = New System.Windows.Forms.Label()
        E_MailLabel = New System.Windows.Forms.Label()
        AdresLabel = New System.Windows.Forms.Label()
        Ehliyet_NoLabel = New System.Windows.Forms.Label()
        Eliyet_TarihiLabel = New System.Windows.Forms.Label()
        Ehliyet_Verilen_YerLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Label1.Location = New System.Drawing.Point(36, 107)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(49, 17)
        Label1.TabIndex = 112
        Label1.Text = "Cinsiyet"
        '
        'Tc_Kimlik_NoLabel
        '
        Tc_Kimlik_NoLabel.AutoSize = True
        Tc_Kimlik_NoLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Tc_Kimlik_NoLabel.Location = New System.Drawing.Point(36, 23)
        Tc_Kimlik_NoLabel.Name = "Tc_Kimlik_NoLabel"
        Tc_Kimlik_NoLabel.Size = New System.Drawing.Size(72, 17)
        Tc_Kimlik_NoLabel.TabIndex = 100
        Tc_Kimlik_NoLabel.Text = "Tc Kimlik No:"
        '
        'SoyadLabel
        '
        SoyadLabel.AutoSize = True
        SoyadLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        SoyadLabel.Location = New System.Drawing.Point(36, 76)
        SoyadLabel.Name = "SoyadLabel"
        SoyadLabel.Size = New System.Drawing.Size(41, 17)
        SoyadLabel.TabIndex = 102
        SoyadLabel.Text = "Soyad:"
        '
        'AdLabel
        '
        AdLabel.AutoSize = True
        AdLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        AdLabel.Location = New System.Drawing.Point(36, 50)
        AdLabel.Name = "AdLabel"
        AdLabel.Size = New System.Drawing.Size(24, 17)
        AdLabel.TabIndex = 101
        AdLabel.Text = "Ad:"
        '
        'Dogum_TarihiLabel
        '
        Dogum_TarihiLabel.AutoSize = True
        Dogum_TarihiLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Dogum_TarihiLabel.Location = New System.Drawing.Point(36, 145)
        Dogum_TarihiLabel.Name = "Dogum_TarihiLabel"
        Dogum_TarihiLabel.Size = New System.Drawing.Size(76, 17)
        Dogum_TarihiLabel.TabIndex = 103
        Dogum_TarihiLabel.Text = "Dogum Tarihi:"
        '
        'Dogum_YeriLabel
        '
        Dogum_YeriLabel.AutoSize = True
        Dogum_YeriLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Dogum_YeriLabel.Location = New System.Drawing.Point(36, 171)
        Dogum_YeriLabel.Name = "Dogum_YeriLabel"
        Dogum_YeriLabel.Size = New System.Drawing.Size(68, 17)
        Dogum_YeriLabel.TabIndex = 104
        Dogum_YeriLabel.Text = "Dogum Yeri:"
        '
        'TelefonLabel
        '
        TelefonLabel.AutoSize = True
        TelefonLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        TelefonLabel.Location = New System.Drawing.Point(36, 197)
        TelefonLabel.Name = "TelefonLabel"
        TelefonLabel.Size = New System.Drawing.Size(48, 17)
        TelefonLabel.TabIndex = 105
        TelefonLabel.Text = "Telefon:"
        '
        'Cep_TelefonuLabel
        '
        Cep_TelefonuLabel.AutoSize = True
        Cep_TelefonuLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Cep_TelefonuLabel.Location = New System.Drawing.Point(36, 223)
        Cep_TelefonuLabel.Name = "Cep_TelefonuLabel"
        Cep_TelefonuLabel.Size = New System.Drawing.Size(74, 17)
        Cep_TelefonuLabel.TabIndex = 106
        Cep_TelefonuLabel.Text = "Cep Telefonu:"
        '
        'E_MailLabel
        '
        E_MailLabel.AutoSize = True
        E_MailLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        E_MailLabel.Location = New System.Drawing.Point(36, 249)
        E_MailLabel.Name = "E_MailLabel"
        E_MailLabel.Size = New System.Drawing.Size(41, 17)
        E_MailLabel.TabIndex = 107
        E_MailLabel.Text = "E-Mail:"
        '
        'AdresLabel
        '
        AdresLabel.AutoSize = True
        AdresLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        AdresLabel.Location = New System.Drawing.Point(36, 275)
        AdresLabel.Name = "AdresLabel"
        AdresLabel.Size = New System.Drawing.Size(42, 17)
        AdresLabel.TabIndex = 108
        AdresLabel.Text = "Adres:"
        '
        'Ehliyet_NoLabel
        '
        Ehliyet_NoLabel.AutoSize = True
        Ehliyet_NoLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Ehliyet_NoLabel.Location = New System.Drawing.Point(36, 312)
        Ehliyet_NoLabel.Name = "Ehliyet_NoLabel"
        Ehliyet_NoLabel.Size = New System.Drawing.Size(60, 17)
        Ehliyet_NoLabel.TabIndex = 109
        Ehliyet_NoLabel.Text = "Ehliyet No:"
        '
        'Eliyet_TarihiLabel
        '
        Eliyet_TarihiLabel.AutoSize = True
        Eliyet_TarihiLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Eliyet_TarihiLabel.Location = New System.Drawing.Point(36, 338)
        Eliyet_TarihiLabel.Name = "Eliyet_TarihiLabel"
        Eliyet_TarihiLabel.Size = New System.Drawing.Size(71, 17)
        Eliyet_TarihiLabel.TabIndex = 110
        Eliyet_TarihiLabel.Text = "Eliyet Tarihi:"
        '
        'Ehliyet_Verilen_YerLabel
        '
        Ehliyet_Verilen_YerLabel.AutoSize = True
        Ehliyet_Verilen_YerLabel.Font = New System.Drawing.Font("Haettenschweiler", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Ehliyet_Verilen_YerLabel.Location = New System.Drawing.Point(36, 364)
        Ehliyet_Verilen_YerLabel.Name = "Ehliyet_Verilen_YerLabel"
        Ehliyet_Verilen_YerLabel.Size = New System.Drawing.Size(105, 17)
        Ehliyet_Verilen_YerLabel.TabIndex = 111
        Ehliyet_Verilen_YerLabel.Text = "Ehliyet Verilen Yer:"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Bay", "Bayan"})
        Me.ComboBox1.Location = New System.Drawing.Point(152, 103)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 113
        Me.ComboBox1.Text = "Bay"
        '
        'TextBox10
        '
        Me.TextBox10.Location = New System.Drawing.Point(152, 362)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(100, 20)
        Me.TextBox10.TabIndex = 99
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(152, 309)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 20)
        Me.TextBox9.TabIndex = 98
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(152, 270)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 97
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(152, 243)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 96
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(152, 216)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 95
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(152, 189)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 94
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(152, 162)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 93
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(152, 73)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 92
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(152, 46)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 91
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(152, 20)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 90
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(152, 336)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker2.TabIndex = 89
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(152, 136)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 88
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Orange
        Me.Button2.Font = New System.Drawing.Font("Haettenschweiler", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button2.Location = New System.Drawing.Point(193, 405)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(80, 28)
        Me.Button2.TabIndex = 114
        Me.Button2.Text = "Kaydet"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Orange
        Me.Button1.Font = New System.Drawing.Font("Haettenschweiler", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(162, Byte))
        Me.Button1.Location = New System.Drawing.Point(309, 405)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(80, 28)
        Me.Button1.TabIndex = 115
        Me.Button1.Text = "Vaz Geç"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(440, 445)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Tc_Kimlik_NoLabel)
        Me.Controls.Add(SoyadLabel)
        Me.Controls.Add(AdLabel)
        Me.Controls.Add(Dogum_TarihiLabel)
        Me.Controls.Add(Dogum_YeriLabel)
        Me.Controls.Add(TelefonLabel)
        Me.Controls.Add(Cep_TelefonuLabel)
        Me.Controls.Add(E_MailLabel)
        Me.Controls.Add(AdresLabel)
        Me.Controls.Add(Ehliyet_NoLabel)
        Me.Controls.Add(Eliyet_TarihiLabel)
        Me.Controls.Add(Ehliyet_Verilen_YerLabel)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Name = "Form5"
        Me.Text = "Form5"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
